package com.swiggy.clone.service;

import com.swiggy.clone.model.OrderItem;
import com.swiggy.clone.repository.ItemRepository;
import com.swiggy.clone.repository.OrderItemRepository;
import com.swiggy.clone.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrderItemService {

    @Autowired
    private OrderItemRepository orderItemRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private ItemRepository itemRepository;

    public List<OrderItem> getAllOrderItems() {
        return orderItemRepository.findAll();
    }

    public OrderItem getOrderItemById(Long id) {
        Optional<OrderItem> orderItem = orderItemRepository.findById(id);
        return orderItem.orElse(null);
    }

    public List<OrderItem> getOrderItemsByOrder(Long orderId) {
        return orderItemRepository.findByOrderId(orderId);
    }

    public String addOrderItem(OrderItem orderItem) {
        if (!orderRepository.existsById(orderItem.getOrderId())) {
            return "Order Not Found - Cannot Add Order Item";
        }

        if (!itemRepository.existsById(orderItem.getItemId())) {
            return "Item Not Found - Cannot Add Order Item";
        }

        if (orderItem.getQuantity() == null || orderItem.getQuantity() <= 0) {
            return "Quantity Must Be Greater Than Zero";
        }

        orderItemRepository.save(orderItem);
        return "Order Item Added Successfully";
    }

    public String deleteOrderItem(Long id) {
        if (orderItemRepository.existsById(id)) {
            orderItemRepository.deleteById(id);
            return "Order Item Removed Successfully";
        }

        return "Order Item Not Found";
    }
}
