package com.restaurant.management.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/external/items")
public class ExternalItemController {

    @Autowired
    private RestTemplate restTemplate;

    @Value("${swiggy.clone.base-url}")
    private String swiggyCloneBaseUrl;

    @GetMapping
    public Object[] getAllItemsFromSwiggyClone() {
        return restTemplate.getForObject(swiggyCloneBaseUrl + "/api/items", Object[].class);
    }

    @GetMapping("/{itemId}")
    public Object getItemFromSwiggyClone(@PathVariable Long itemId) {
        return restTemplate.getForObject(swiggyCloneBaseUrl + "/api/items/" + itemId, Object.class);
    }

    @GetMapping("/available-count")
    public int getAvailableItemCount() {
        List<Map<String, Object>> items = restTemplate.getForObject(
                swiggyCloneBaseUrl + "/api/items", List.class);

        if (items == null) {
            return 0;
        }

        int count = 0;
        for (Map<String, Object> item : items) {
            if (Boolean.TRUE.equals(item.get("available"))) {
                count++;
            }
        }
        return count;
    }
}
