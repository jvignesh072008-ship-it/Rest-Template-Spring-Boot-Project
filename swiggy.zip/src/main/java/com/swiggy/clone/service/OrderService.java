package com.swiggy.clone.service;

import com.swiggy.clone.model.Order;
import com.swiggy.clone.model.OrderStatus;
import com.swiggy.clone.repository.OrderRepository;
import com.swiggy.clone.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private UserRepository userRepository;

    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    public Order getOrderById(Long id) {
        Optional<Order> order = orderRepository.findById(id);
        return order.orElse(null);
    }

    public List<Order> getOrdersByUser(Long userId) {
        return orderRepository.findByUserId(userId);
    }

    public String placeOrder(Order order) {
        if (!userRepository.existsById(order.getUserId())) {
            return "User Not Found - Cannot Place Order";
        }

        order.setStatus(OrderStatus.PLACED);
        order.setOrderDate(LocalDateTime.now());
        orderRepository.save(order);
        return "Order Placed Successfully";
    }

    public String updateOrderStatus(Long id, OrderStatus status) {
        Optional<Order> existing = orderRepository.findById(id);

        if (existing.isPresent()) {
            Order order = existing.get();
            order.setStatus(status);
            orderRepository.save(order);
            return "Order Status Updated Successfully";
        }

        return "Order Not Found";
    }

    public String cancelOrder(Long id) {
        Optional<Order> existing = orderRepository.findById(id);

        if (existing.isPresent()) {
            Order order = existing.get();
            order.setStatus(OrderStatus.CANCELLED);
            orderRepository.save(order);
            return "Order Cancelled Successfully";
        }

        return "Order Not Found";
    }
}
