package com.swiggy.clone.service;

import com.swiggy.clone.model.Item;
import com.swiggy.clone.repository.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ItemService {

    @Autowired
    private ItemRepository itemRepository;

    public List<Item> getAllItems() {
        return itemRepository.findAll();
    }

    public Item getItemById(Long id) {
        Optional<Item> item = itemRepository.findById(id);
        return item.orElse(null);
    }

    public String addItem(Item item) {
        itemRepository.save(item);
        return "Item Added Successfully";
    }

    public String updateItem(Long id, Item item) {
        Optional<Item> existing = itemRepository.findById(id);

        if (existing.isPresent()) {
            Item updatedItem = existing.get();
            updatedItem.setName(item.getName());
            updatedItem.setDescription(item.getDescription());
            updatedItem.setPrice(item.getPrice());
            updatedItem.setCategory(item.getCategory());
            itemRepository.save(updatedItem);
            return "Item Updated Successfully";
        }

        return "Item Not Found";
    }

    public String toggleAvailability(Long id) {
        Optional<Item> existing = itemRepository.findById(id);

        if (existing.isPresent()) {
            Item item = existing.get();
            item.setAvailable(!item.isAvailable());
            itemRepository.save(item);
            return "Item Availability Toggled Successfully";
        }

        return "Item Not Found";
    }

    public String deleteItem(Long id) {
        if (itemRepository.existsById(id)) {
            itemRepository.deleteById(id);
            return "Item Deleted Successfully";
        }

        return "Item Not Found";
    }
}
