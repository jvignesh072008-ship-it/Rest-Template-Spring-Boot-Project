package com.swiggy.clone.service;

import com.swiggy.clone.model.User;
import com.swiggy.clone.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public User getUserById(Long id) {
        Optional<User> user = userRepository.findById(id);
        return user.orElse(null);
    }

    public String addUser(User user) {
        userRepository.save(user);
        return "User Added Successfully";
    }

    public String updateUser(Long id, User user) {
        Optional<User> existing = userRepository.findById(id);

        if (existing.isPresent()) {
            User updatedUser = existing.get();
            updatedUser.setName(user.getName());
            updatedUser.setEmail(user.getEmail());
            updatedUser.setPhone(user.getPhone());
            updatedUser.setAddress(user.getAddress());
            userRepository.save(updatedUser);
            return "User Updated Successfully";
        }

        return "User Not Found";
    }

    public String deleteUser(Long id) {
        if (userRepository.existsById(id)) {
            userRepository.deleteById(id);
            return "User Deleted Successfully";
        }

        return "User Not Found";
    }
}
