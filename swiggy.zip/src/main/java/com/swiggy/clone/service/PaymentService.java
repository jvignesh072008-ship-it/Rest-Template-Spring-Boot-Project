package com.swiggy.clone.service;

import com.swiggy.clone.model.Payment;
import com.swiggy.clone.model.PaymentStatus;
import com.swiggy.clone.repository.OrderRepository;
import com.swiggy.clone.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private OrderRepository orderRepository;

    public List<Payment> getAllPayments() {
        return paymentRepository.findAll();
    }

    public Payment getPaymentById(Long id) {
        Optional<Payment> payment = paymentRepository.findById(id);
        return payment.orElse(null);
    }

    public List<Payment> getPaymentsByOrder(Long orderId) {
        return paymentRepository.findByOrderId(orderId);
    }

    public String createPayment(Payment payment) {
        if (!orderRepository.existsById(payment.getOrderId())) {
            return "Order Not Found - Cannot Create Payment";
        }

        payment.setStatus(PaymentStatus.PENDING);
        payment.setPaymentDate(LocalDateTime.now());
        paymentRepository.save(payment);
        return "Payment Created Successfully";
    }

    public String updatePaymentStatus(Long id, PaymentStatus status) {
        Optional<Payment> existing = paymentRepository.findById(id);

        if (existing.isPresent()) {
            Payment payment = existing.get();
            payment.setStatus(status);
            paymentRepository.save(payment);
            return "Payment Status Updated Successfully";
        }

        return "Payment Not Found";
    }
}
