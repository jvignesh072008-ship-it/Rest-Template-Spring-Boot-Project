package com.swiggy.clone.controller;

import com.swiggy.clone.model.Item;
import com.swiggy.clone.service.ItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/items")
public class ItemController {

    @Autowired
    private ItemService itemService;

    @GetMapping
    public List<Item> getAllItems() {
        return itemService.getAllItems();
    }

    @GetMapping("/{id}")
    public Item getItemById(@PathVariable Long id) {
        return itemService.getItemById(id);
    }

    @PostMapping
    public String addItem(@RequestBody Item item) {
        return itemService.addItem(item);
    }

    @PutMapping("/{id}")
    public String updateItem(@PathVariable Long id, @RequestBody Item item) {
        return itemService.updateItem(id, item);
    }

    @PutMapping("/{id}/toggle-availability")
    public String toggleAvailability(@PathVariable Long id) {
        return itemService.toggleAvailability(id);
    }

    @DeleteMapping("/{id}")
    public String deleteItem(@PathVariable Long id) {
        return itemService.deleteItem(id);
    }
}
