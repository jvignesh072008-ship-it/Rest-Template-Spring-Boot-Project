package com.restaurant.management.service;

import com.restaurant.management.model.Restaurant;
import com.restaurant.management.repository.RestaurantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RestaurantService {

    @Autowired
    private RestaurantRepository restaurantRepository;

    public List<Restaurant> getAllRestaurants() {
        return restaurantRepository.findAll();
    }

    public Restaurant getRestaurantById(Long id) {
        Optional<Restaurant> restaurant = restaurantRepository.findById(id);
        return restaurant.orElse(null);
    }

    public List<Restaurant> getByCuisineType(String cuisineType) {
        return restaurantRepository.findByCuisineType(cuisineType);
    }

    public boolean isRestaurantActive(Long id) {
        Optional<Restaurant> restaurant = restaurantRepository.findById(id);
        return restaurant.map(Restaurant::isActive).orElse(false);
    }

    public String addRestaurant(Restaurant restaurant) {
        restaurant.setActive(true);
        restaurantRepository.save(restaurant);
        return "Restaurant Added Successfully";
    }

    public String updateRestaurant(Long id, Restaurant restaurant) {
        Optional<Restaurant> existing = restaurantRepository.findById(id);

        if (existing.isPresent()) {
            Restaurant updatedRestaurant = existing.get();
            updatedRestaurant.setName(restaurant.getName());
            updatedRestaurant.setAddress(restaurant.getAddress());
            updatedRestaurant.setCuisineType(restaurant.getCuisineType());
            updatedRestaurant.setRating(restaurant.getRating());
            restaurantRepository.save(updatedRestaurant);
            return "Restaurant Updated Successfully";
        }

        return "Restaurant Not Found";
    }

    public String deleteRestaurant(Long id) {
        if (restaurantRepository.existsById(id)) {
            restaurantRepository.deleteById(id);
            return "Restaurant Deleted Successfully";
        }

        return "Restaurant Not Found";
    }
}
